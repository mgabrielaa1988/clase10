#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

typedef struct{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct{
    int legajo;
    char nombre[20];
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
    int isEmpty;
}eEmpleado;

int menu();
void inicializarEmpleados(eEmpleado vec[],int tam);
int buscarLibre(eEmpleado vec[],int tam);
void mostrarEmpleados(eEmpleado vec[],int tam);
void mostrarEmpleado(eEmpleado vec[]);
int buscarEmpleado(eEmpleado vec[],int tam,int legajo);
void alta(eEmpleado vec[],int tam);

int main()
{
    int salir = 0;

    eEmpleado gente[50];
    inicializarEmpleados(gente,50);

    do
    {
        switch(menu())
        {
        case 1:
            break;
        case 2:
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
            break;
        case 6:
            salir = 1;
            break;
        default:
            printf("Opcion invalida...\n");
            system("pause");
            break;
        }
    }
    while(salir!=1);

    return 0;
}

int menu()
{
    int opcion;

    printf("---ABM EMPLEADOS---\n");
    printf("-1- Alta\n");
    printf("-2- Baja\n");
    printf("-3- Modificacion\n");
    printf("-4- Listar\n");
    printf("-5- Ordenar\n");
    printf("-6- Salir\n");
    printf("Elija una opcion: ");

    scanf("%d",&opcion);

    system("cls");
    return opcion;
}

void inicializarEmpleados(eEmpleado vec[],int tam){
    int i;
    for(i=0;i<tam;i++){
        vec[i].isEmpty = 1;
    }
}

int buscarLibre(eEmpleado vec[],int tam){
    int i,indice=-1;
    for(i=0;i<tam;i++){
        if(vec[i].isEmpty == 1){
            indice = i;
            break;
        }
    }
    return indice;
}

void mostrarEmpleados(eEmpleado vec[],int tam){
    int i;
    for(i=0;i<tam;i++){
        if(vec[i].isEmpty!=1){
            mostrarEmpleado(vec[i])
        }
    }
}

void mostrarEmpleado(eEmpleado vec[]){
    printf("%d\t%s\t%c\t%.2f\t%d/%d/%d\n",vec.legajo,vec.nombre,vec.sexo,vec.sueldo,vec.fechaIngreso.dia,vec.fechaIngreso.mes,vec.fechaIngreso.anio);
}

int buscarEmpleado(eEmpleado vec[],int tam,int legajo){
    int i;
    for(i=0;i<tam;i++){
        if(vec[i].legajo == legajo){
            printf("Legajo ya existente\n");
            break;
        }
        else{
            i=-1;
        }
    }
    return i;
}

void alta(eEmpleado vec[],int tam){
    eEmpleado nuevoEmpleado;
    int indice,auxLegajo,esta;

    indice=buscarLibre(vec,tam);
    if(indice==-1){
        printf("No hay mas lugar en memoria");
    }
    else{
        printf("Legajo: ");
        scanf("%d",&auxLegajo);
    }
    esta=buscarEmpleado(vec,tam,auxLegajo);
    if()

}

